#include <SPI.h>
#include <MFRC522.h>
#include <Keypad.h>
#include <Servo.h>
#include <SoftwareSerial.h>

// --- GSM A9 Podešavanja (Simulirano preko Serijskog monitora) ---
SoftwareSerial A9Serial(6, 5); 
const String TARGET_PHONE = "+38268108769";

// --- RFID Podešavanja ---
#define RST_PIN         9   
#define SS_PIN          10  
MFRC522 rfid(SS_PIN, RST_PIN);


byte UID_Petar[4] = {0x01, 0x02, 0x03, 0x04};
byte UID_Marko[4] = {0x11, 0x22, 0x33, 0x44};

// --- Tastatura Podešavanja ---
const byte REDOVI = 3;
const byte KOLONE = 3;

char tasteri[REDOVI][KOLONE] = {
  {'1','2','3'},
  {'4','5','6'},
  {'7','8','9'}
};

byte pinoviRedova[REDOVI] = {A1, A2, A3}; 
byte pinoviKolona[KOLONE] = {A4, A5, 8};  

Keypad tastatura = Keypad(makeKeymap(tasteri), pinoviRedova, pinoviKolona, REDOVI, KOLONE);

String tacanPIN = "1234"; 
String uneseniPIN = "";   

// --- Servo Podešavanja ---
Servo mojServo;
#define SERVO_PIN A0
int pozicijaZakljucano = 0;   
int pozicijaOtkljucano = 90; 

// --- Buzzer Podešavanja ---
#define BUZZER_PIN 7 
int frekvencijaTona = 1000; 

// --- Tilt i Ultrazvučni Senzor ---
#define TILT_PIN 2 // Povezan na srednji pin Slide Switch-a
#define TRIG_PIN 4
#define ECHO_PIN 3

bool sefOtkljucan = false; 

// --- TAJMER ZA ULTRAZVUČNI SENZOR ---
unsigned long prethodnoVrijemeMerenja = 0;
const long intervalMerenja = 1000; // Mjeri razdaljinu svaki sekund

// --- SMS COOLDOWN mehanizam ---
unsigned long vrijemePoslednjegSMS = 0;
const long SMS_COOLDOWN = 60000; // 60 sekundi pauze između SMS poruka

// --- NON-BLOCKING ALARM ---
bool alarmAktivan = false;
unsigned long alarmPocetak = 0;
const long TRAJANJE_ALARMA = 4000; // Koliko dugo zvuči alarm (ms)

void setup() {
  Serial.begin(115200);
  while (!Serial) { ; } 
  
  Serial.println("Cekam 2 sekunde da se GSM modul podigne (simulacija)...");
  delay(2000); 
  
  SPI.begin();
  rfid.PCD_Init();
  
  mojServo.attach(SERVO_PIN);
  mojServo.write(pozicijaZakljucano); 
  
  pinMode(BUZZER_PIN, OUTPUT); 
  pinMode(TILT_PIN, INPUT_PULLUP);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  
  A9Serial.begin(115200); 
  Serial.println("\n--- Pokretanje GSM A9 Modula (115200) ---");
  delay(1000); 

  Serial.println("--- SIGURNOSNI SEF SPREMAN ---");
  Serial.println("Prislonite RFID karticu ili ukucajte PIN:");
}

void loop() {
  // Passthrough za ručne komande
  if (A9Serial.available()) { Serial.write(A9Serial.read()); }
  if (Serial.available()) { A9Serial.write(Serial.read()); }

  // Upravljanje non-blocking alarmom (zujalica)
  upravljajAlarmom();

  // --- ZAŠTITA 1: Tilt Senzor (Simuliran kliznim prekidačem) ---
  if (digitalRead(TILT_PIN) == LOW) {
    Serial.println("\n[ALARM] Detektovano pomjeranje sefa (Slide Switch okidac)!");
    aktivirajAlarm("ALARM: Detektovano pomjeranje ili nagib sefa!");
  }

// --- ZAŠTITA 2: Ultrazvučni senzor ---
  unsigned long trenutnoVrijeme = millis();
  if (!sefOtkljucan && (trenutnoVrijeme - prethodnoVrijemeMerenja >= intervalMerenja)) {
    prethodnoVrijemeMerenja = trenutnoVrijeme; 

    long distanca = izmjeriDistancu();
    
    // Provjeravamo da li je očitana validna distanca (0 znači greška senzora)
    if (distanca > 0) {
      // Referentna udaljenost zadnjeg zida je 32cm. 
      // Dozvoljavamo toleranciju +/- 3cm zbog šuma (opseg 29-35cm je bezbjedan).
      if (distanca < 29 || distanca > 35) { 
        Serial.print("\n[ALARM] Promjena distance! (Ocekivano ~32cm, ocitano: ");
        Serial.print(distanca);
        Serial.println(" cm)");
        aktivirajAlarm("ALARM: Neovlascen pristup - promjena distance u sefu!");
      }
    }
  }

  // --- 1. PROVJERA RFID-a ---
  if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
    Serial.print("Ocitan RFID kod:");
    for (byte i = 0; i < rfid.uid.size; i++) {
      Serial.print(rfid.uid.uidByte[i] < 0x10 ? " 0" : " ");
      Serial.print(rfid.uid.uidByte[i], HEX);
    }
    Serial.println();

    if (uporediUID(rfid.uid.uidByte, UID_Petar)) {
      Serial.println("Korisnik: Petar Petrovic -> ODOBRENO!");
      zvukUspjeh();
      otkljucajSef();
    } 
    else if (uporediUID(rfid.uid.uidByte, UID_Marko)) {
      Serial.println("Korisnik: Marko Markovic -> ODOBRENO!");
      zvukUspjeh();
      otkljucajSef();
    } 
    else {
      Serial.println("Korisnik: NEPOZNAT -> ODBIJEN!");
      zvukGreska();
      sendSMS("ALARM: Pokusaj otkljucavanja nepoznatom RFID karticom!", TARGET_PHONE);
    }
    rfid.PICC_HaltA(); 
  }

  // --- 2. PROVJERA TASTATURE ---
  char taster = tastatura.getKey();
  if (taster) {
    Serial.print("Pritisnuto: ");
    Serial.println(taster);
    tone(BUZZER_PIN, 1500, 30); 
    uneseniPIN += taster; 
    
    if (uneseniPIN.length() == 4) {
      if (uneseniPIN == tacanPIN) {
        Serial.println("PIN tacan! Pristup odobren.");
        zvukUspjeh();
        otkljucajSef();
      } else {
        Serial.println("Pogresan PIN! Pristup odbijen.");
        zvukGreska();
        uneseniPIN = ""; 
        sendSMS("ALARM: Pokusan unos pogresnog PIN koda na sefu!", TARGET_PHONE);
      }
    }
  }
}

// --- FUNKCIJE ---

long izmjeriDistancu() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  
  long trajanje = pulseIn(ECHO_PIN, HIGH, 10000); 
  long distanca = trajanje * 0.034 / 2;
  return distanca;
}

void aktivirajAlarm(String poruka) {
  alarmAktivan = true;
  alarmPocetak = millis();

  unsigned long trenutnoVrijeme = millis();
  if (trenutnoVrijeme - vrijemePoslednjegSMS >= SMS_COOLDOWN) {
    vrijemePoslednjegSMS = trenutnoVrijeme;
    sendSMS(poruka, TARGET_PHONE);
  } else {
    long preostaloCooldown = (SMS_COOLDOWN - (trenutnoVrijeme - vrijemePoslednjegSMS)) / 1000;
    Serial.print("[SMS Cooldown] Sljedeci SMS za ");
    Serial.print(preostaloCooldown);
    Serial.println(" sekundi.");
  }
}

void upravljajAlarmom() {
  if (!alarmAktivan) return;
  unsigned long proteklo = millis() - alarmPocetak;

  if (proteklo >= TRAJANJE_ALARMA) {
    noTone(BUZZER_PIN);
    alarmAktivan = false;
    return;
  }

  unsigned long faza = proteklo % 400;
  if (faza < 150) {
    tone(BUZZER_PIN, 1200);
  } else if (faza < 200) {
    noTone(BUZZER_PIN);
  } else if (faza < 350) {
    tone(BUZZER_PIN, 900);
  } else {
    noTone(BUZZER_PIN);
  }
}

bool uporediUID(byte *procitani, byte *korisnicki) {
  for (byte i = 0; i < 4; i++) {
    if (procitani[i] != korisnicki[i]) { return false; }
  }
  return true; 
}

void otkljucajSef() {
  sefOtkljucan = true; 
  Serial.println("Otvaram bravu...");
  mojServo.write(pozicijaOtkljucano);
  delay(5000); 
  Serial.println("Zakljucavam bravu...");
  mojServo.write(pozicijaZakljucano);
  uneseniPIN = ""; 
  sefOtkljucan = false; 
  Serial.println("\nSef je ponovo zakljucan. Cekam unos...");
}

void zvukUspjeh() {
  tone(BUZZER_PIN, frekvencijaTona, 250); 
  delay(250); 
}

void zvukGreska() {
  for (int i = 0; i < 5; i++) {
    tone(BUZZER_PIN, 800, 80); 
    delay(150);                
  }
}

void sendSMS(String message, String phoneNumber) {
  A9Serial.println("AT+CMGF=1"); 
  delay(1000);
  
  A9Serial.print("AT+CMGS=\"");
  A9Serial.print(phoneNumber);
  A9Serial.println("\"");
  delay(1000);
  
  A9Serial.print(message);
  delay(500);
  
  A9Serial.write(26); 
  delay(1000); // Wokwi optimizacija: smanjen delay za završetak slanja SMS-a
  
  Serial.println("\n[Sistem - Wokwi Simulacija]: AT komande za SMS uspesno izvrsene.");
  Serial.print("Poslata poruka: ");
  Serial.println(message);
}